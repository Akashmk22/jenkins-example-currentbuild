# jenkins-example-currentbuild

Repository to support https://www.youtube.com/watch?v=gcUORgHuna4

## Links

* [Getting started with Pipeline - Global Variable Reference](https://www.jenkins.io/doc/book/pipeline/getting-started/#global-variable-reference)
* [Sidebar Link](https://plugins.jenkins.io/sidebar-link/)
* [Shared library used in controller](https://github.com/darinpope/github-api-global-lib)